package com.buildoverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var build: BuildData

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build = BuildData.load(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        setContentView(ScrollView(this).apply { addView(root) })
        render()
    }

    private fun render() {
        root.removeAllViews()
        root.addView(TextView(this).apply {
            text = "1) Démarrer la bulle  2) Ouvrez le jeu  3) À chaque montée de niveau, touchez la bulle 🎯 pour lire les cartes.\n\nLes compteurs se mettent à jour tout seuls quand vous scannez à chaque niveau. Vous pouvez les corriger ici avec − et +."
            textSize = 14f
        })
        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { action() }; root.addView(this)
        }
        btn("Démarrer la bulle") { start() }
        btn("Arrêter") {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        }
        btn("Nouvelle partie : tout remettre à zéro") {
            BuildData.resetAll(this)
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_RESET))
            render()
        }
        for (s in build.spells) {
            root.addView(TextView(this).apply { text = s.name; textSize = 17f; setPadding(0, 28, 0, 4) })
            for (b in s.bonuses) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                val label = TextView(this).apply { textSize = 14f }
                fun upd() { label.text = "${b.name}  ${BuildData.count(this@MainActivity, s, b)}/${b.count}" }
                upd()
                row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(Button(this).apply { text = "−"; setOnClickListener {
                    BuildData.setCount(this@MainActivity, s, b, BuildData.count(this@MainActivity, s, b) - 1); upd() } })
                row.addView(Button(this).apply { text = "+"; setOnClickListener {
                    BuildData.setCount(this@MainActivity, s, b, BuildData.count(this@MainActivity, s, b) + 1); upd() } })
                root.addView(row)
            }
        }
    }

    override fun onResume() { super.onResume(); if (::root.isInitialized) render() }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Autorisez « Afficher par-dessus d'autres apps », puis revenez.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), 42)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Bulle active. Ouvrez le jeu.", Toast.LENGTH_LONG).show()
        }
    }
}
