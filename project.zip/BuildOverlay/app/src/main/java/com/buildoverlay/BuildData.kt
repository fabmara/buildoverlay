package com.buildoverlay

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer

data class Bonus(val name: String, val count: Int) {
    val tokens: Set<String> = tokens(name)
    val key: String = norm(name)
}

data class Spell(val name: String, val special: String?, val bonuses: List<Bonus>) {
    val key: String = norm(name)
}

class BuildData(val spells: List<Spell>) {
    companion object {
        fun load(ctx: Context): BuildData {
            val txt = ctx.assets.open("build.json").bufferedReader().use { it.readText() }
            val sa = JSONObject(txt).getJSONArray("spells")
            return BuildData((0 until sa.length()).map {
                val o = sa.getJSONObject(it)
                val ba = o.optJSONArray("bonuses")
                val bonuses = if (ba == null) emptyList() else (0 until ba.length()).map { i ->
                    val b = ba.getJSONObject(i); Bonus(b.getString("name"), b.getInt("count"))
                }
                Spell(o.getString("name"), o.optString("special").ifEmpty { null }, bonuses)
            })
        }

        private fun prefs(ctx: Context) = ctx.getSharedPreferences("counts", Context.MODE_PRIVATE)
        private fun k(s: Spell, b: Bonus) = s.key + "|" + b.key
        fun count(ctx: Context, s: Spell, b: Bonus) = prefs(ctx).getInt(k(s, b), 0)
        fun setCount(ctx: Context, s: Spell, b: Bonus, v: Int) =
            prefs(ctx).edit().putInt(k(s, b), v.coerceIn(0, b.count)).apply()
        fun resetAll(ctx: Context) = prefs(ctx).edit().clear().apply()
    }

    fun matchSpell(title: String): Spell? {
        val t = norm(title)
        if (t.length < 3) return null
        var best: Spell? = null
        var bs = 0.0
        for (s in spells) {
            val sc = 1.0 - levenshtein(t, s.key).toDouble() / maxOf(t.length, s.key.length)
            if (sc > bs) { bs = sc; best = s }
        }
        return if (bs >= 0.75) best else null
    }
}

private val STOP = setOf("de", "des", "du", "la", "le", "les", "l", "d", "en", "a", "un", "une", "au")

fun tokens(s: String): Set<String> =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]+"), " ")
        .trim().split(" ")
        .filter { it.isNotEmpty() && it !in STOP }
        .map {
            when (it) {
                "dommages", "dommage" -> "degat"
                "recuperation" -> "recup"
                else -> it.removeSuffix("s")
            }
        }
        .toSet()

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]"), "")

fun levenshtein(a: String, b: String): Int {
    val dp = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        var prev = dp[0]
        dp[0] = i
        for (j in 1..b.length) {
            val tmp = dp[j]
            dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = tmp
        }
    }
    return dp[b.length]
}
