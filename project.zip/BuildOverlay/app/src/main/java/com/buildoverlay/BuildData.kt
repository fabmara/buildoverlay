package com.buildoverlay

import android.content.Context
import org.json.JSONObject
import java.text.Normalizer

data class BuildItem(val name: String, val target: Int, val bonuses: List<String>) {
    val key: String = norm(name)
}

object BuildData {
    fun load(ctx: Context): List<BuildItem> {
        val txt = ctx.assets.open("build.json").bufferedReader().use { it.readText() }
        val arr = JSONObject(txt).getJSONArray("items")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            val b = o.optJSONArray("bonuses")
            BuildItem(
                o.getString("name"),
                o.getInt("target"),
                if (b == null) emptyList() else (0 until b.length()).map { i -> b.getString(i) }
            )
        }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("counts", Context.MODE_PRIVATE)
    fun count(ctx: Context, item: BuildItem) = prefs(ctx).getInt(item.key, 0)
    fun increment(ctx: Context, item: BuildItem) {
        prefs(ctx).edit().putInt(item.key, count(ctx, item) + 1).apply()
    }
    fun resetAll(ctx: Context) = prefs(ctx).edit().clear().apply()

    fun bestMatch(items: List<BuildItem>, rawTitle: String): BuildItem? {
        val t = norm(rawTitle)
        if (t.length < 3) return null
        var best: BuildItem? = null
        var bestScore = 0.0
        for (it in items) {
            val d = levenshtein(t, it.key)
            val s = 1.0 - d.toDouble() / maxOf(t.length, it.key.length)
            if (s > bestScore) { bestScore = s; best = it }
        }
        return if (bestScore >= 0.75) best else null
    }
}

fun norm(s: String): String =
    Normalizer.normalize(s, Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "")
        .lowercase()
        .replace(Regex("[^a-z0-9]"), "")

fun levenshtein(a: String, b: String): Int {
    val dp = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        var prev = dp[0]
        dp[0] = i
        for (j in 1..b.length) {
            val tmp = dp[j]
            dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
            prev = tmp
        }
    }
    return dp[b.length]
}
