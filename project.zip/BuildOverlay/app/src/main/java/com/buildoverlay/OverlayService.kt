package com.buildoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        const val ACTION_RESET = "reset"
        private const val CHANNEL = "overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var build: BuildData
    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").also { it.start() }
    private val bg = Handler(bgThread.looper)
    private val lock = Any()

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastImage: Image? = null
    private var capW = 0
    private var capH = 0

    private var bubble: TextView? = null
    private val chips = mutableListOf<View>()
    private var scanning = false
    private class Seen(val level: Int, val picks: List<String?>)
    private val seen = HashMap<String, Seen>()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (intent?.action == ACTION_RESET) { seen.clear(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        build = BuildData.load(this)
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        ensureCapture()
        addBubble()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Build Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Build Overlay actif")
            .setContentText("Touchez la bulle 🎯 dans le jeu pour scanner")
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_delete), "Arrêter", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun realSize(): IntArray {
        val m = DisplayMetrics()
        val d = getSystemService(DisplayManager::class.java).getDisplay(0)
        @Suppress("DEPRECATION") d.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun ensureCapture() {
        val (w, h, dpi) = realSize().let { Triple(it[0], it[1], it[2]) }
        if (display != null && w == capW && h == capH) return
        synchronized(lock) { lastImage?.close(); lastImage = null }
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) synchronized(lock) { lastImage?.close(); lastImage = img }
        }, bg)
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        } else {
            display!!.resize(w, h, dpi)
            display!!.surface = r.surface
        }
        reader?.close()
        reader = r
        capW = w; capH = h
    }

    private fun overlayParams(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x; this.y = y
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun addBubble() {
        val lp = overlayParams(20, 300)
        val v = TextView(this).apply {
            text = "🎯"; textSize = 22f; gravity = Gravity.CENTER
            width = 130; height = 130
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(150, 20, 20, 20)) }
        }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > 12 || abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) scan()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    private fun clearChips() {
        chips.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        chips.clear()
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        clearChips()
        bubble?.visibility = View.INVISIBLE
        ensureCapture()
        main.postDelayed({ capture() }, 450)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val full = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private fun capture() {
        val bmp = synchronized(lock) { lastImage?.let { toBitmap(it) } }
        bubble?.visibility = View.VISIBLE
        if (bmp == null) {
            Toast.makeText(this, "Capture impossible (écran protégé ?)", Toast.LENGTH_SHORT).show()
            scanning = false; return
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { showResults(it, bmp); scanning = false }
            .addOnFailureListener {
                Toast.makeText(this, "Erreur OCR", Toast.LENGTH_SHORT).show(); scanning = false
            }
    }

    private fun dist(a: Int, b: Int): Int =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) + abs((a and 255) - (b and 255))

    private val creams = intArrayOf(0xF2EDD0.toInt(), 0xFFF8DE.toInt(), 0xFFF7D5.toInt())

    // 1 = losange doré, 2 = losange d'une autre couleur (niveaux 6-10), 0 = vide
    private fun slotType(bmp: Bitmap, x: Int, y: Int): Int {
        if (x < 3 || y < 3 || x >= bmp.width - 3 || y >= bmp.height - 3) return 0
        val m = bmp.getPixel(x, y)
        for (dx in intArrayOf(-3, 0, 3)) for (dy in intArrayOf(-3, 0, 3))
            if (dist(bmp.getPixel(x + dx, y + dy), m) > 45) return 0
        val r = (m shr 16) and 255; val g = (m shr 8) and 255; val b = m and 255
        if (r > 200 && g in 110..205 && b < 120 && r - b > 100) return 1
        return if (creams.all { dist(m, it) > 90 }) 2 else 0
    }

    private fun isPurple(p: Int): Boolean {
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        return b > g + 30 && b > r + 25
    }

    // niveau total du sort (déblocage + améliorations + éveil), lu sur les 5 losanges :
    // niveaux 1-5 = losanges dorés ; à partir du 6 les losanges passent au violet, de gauche à droite
    private fun spellLevel(bmp: Bitmap, cx: Int): Int {
        val w = bmp.width; val h = bmp.height
        val sp = 42.0 * w / 2340.0
        var bg = 0; var bo = 0
        var y = (0.69 * h).toInt()
        val yEnd = (0.77 * h).toInt()
        while (y <= yEnd) {
            var g = 0; var o = 0
            for (k in -2..2) when (slotType(bmp, (cx + k * sp).toInt(), y)) { 1 -> g++; 2 -> o++ }
            if (g + o > bg + bo) { bg = g; bo = o }
            y += 2
        }
        var purple = 0
        val x0 = (cx - 2.6 * sp).toInt().coerceAtLeast(0)
        val x1 = (cx + 2.6 * sp).toInt().coerceAtMost(w - 1)
        y = (0.69 * h).toInt()
        while (y <= yEnd) {
            var x = x0
            while (x <= x1) { if (isPurple(bmp.getPixel(x, y))) purple++; x += 2 }
            y += 2
        }
        return if (purple >= 12) 5 + bo else bg
    }

    private class Card(val cx: Int, val cy: Int, val unlock: Boolean, val title: String, val spell: Spell?,
                       val bonus: Bonus?, val special: Boolean, val level: Int)

    private fun showResults(res: Text, bmp: Bitmap) {
        val w = bmp.width; val h = bmp.height
        val lines = res.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
        val eveilTitle = lines.firstOrNull { val n = norm(it.text); n.contains("eveil") && n.contains("choisis") }
        if (eveilTitle != null) { showEveilChoices(lines, eveilTitle, w, h); return }
        val headers = lines.filter {
            val n = norm(it.text)
            n.length <= 12 && (n.contains("debloquer") || n.contains("ameliorer"))
        }
        if (headers.isEmpty()) {
            Toast.makeText(this, "Écran de montée de niveau non détecté", Toast.LENGTH_SHORT).show(); return
        }
        val cards = headers.map { hd ->
            val hb = hd.boundingBox!!
            val unlock = norm(hd.text).contains("debloquer")
            val cx = hb.centerX()
            val inCol = lines.filter { l ->
                val b = l.boundingBox!!
                l !== hd && b.centerY() > hb.bottom - 2 && abs(b.centerX() - cx) < 0.14 * w
            }.sortedBy { it.boundingBox!!.top }
            val cand = inCol.filter { it.boundingBox!!.centerY() < hb.bottom + 0.14 * h }
            var title = ""
            val used = mutableSetOf<Text.Line>()
            if (cand.isNotEmpty()) {
                title = cand[0].text; used.add(cand[0])
                var prev = cand[0].boundingBox!!
                for (l in cand.drop(1)) {
                    val b = l.boundingBox!!
                    if (b.top - prev.bottom < 0.5 * prev.height()) { title += " " + l.text; used.add(l); prev = b } else break
                }
            }
            val desc = inCol.filter { it !in used && it.boundingBox!!.centerY() < 0.71 * h }.joinToString(" ") { it.text }
            val spell = if (title.isEmpty()) null else build.matchSpell(title)
            var bonus: Bonus? = null; var special = false
            if (spell != null && !unlock) {
                val dt = tokens("$desc $title")
                bonus = spell.bonuses.firstOrNull { it.tokens.isNotEmpty() && dt.containsAll(it.tokens) }
                val sp = spell.special?.let { tokens(it) }
                special = spell.special != null && ("eveil" in dt || (bonus == null && sp != null && dt.containsAll(sp)))
                if (special) bonus = null
            }
            val level = if (spell != null) spellLevel(bmp, cx) else 0
            Card(cx, hb.centerY(), unlock, title, spell, bonus, special, level)
        }

        // déduire le bonus pris au niveau précédent : le niveau du sort a augmenté de 1
        for ((key, group) in cards.filter { it.spell != null }.groupBy { it.spell!!.key }) {
            val lvl = group[0].level
            val prev = seen[key]
            if (prev != null && lvl == prev.level + 1 && prev.picks.size == 1) {
                val bk = prev.picks[0]
                val sp = group[0].spell!!
                val bo = sp.bonuses.firstOrNull { it.key == bk }
                if (bo != null) BuildData.setCount(this, sp, bo, BuildData.count(this, sp, bo) + 1)
            }
            seen[key] = Seen(lvl, group.map { it.bonus?.key })
        }

        for (c in cards) {
            val label: String; val color: Int
            val ok = Color.rgb(30, 130, 60); val bad = Color.rgb(180, 40, 40); val warn = Color.rgb(200, 120, 0)
            if (c.title.isEmpty()) { label = "❓ Non lu"; color = Color.GRAY }
            else if (c.spell == null) { label = "❌ Hors build"; color = bad }
            else if (c.unlock) { label = "✅ Sort du build"; color = ok }
            else if (c.bonus != null) {
                val n = BuildData.count(this, c.spell, c.bonus)
                if (n >= c.bonus.count) { label = "⚠️ Max $n/${c.bonus.count}"; color = warn }
                else { label = "✅ Prendre $n/${c.bonus.count}"; color = ok }
            } else if (c.special) { label = "✅ Éveil"; color = ok }
            else { label = "➖ Hors build"; color = Color.rgb(110, 110, 120) }
            addChip(label, color, c.cx, c.cy)
        }
        addWatcher()
        main.postDelayed({ clearChips() }, 12000)
    }

    private fun showEveilChoices(lines: List<Text.Line>, titleLine: Text.Line, w: Int, h: Int) {
        val tb = titleLine.boundingBox!!
        val nameLine = lines.filter {
            val b = it.boundingBox!!
            it !== titleLine && b.top >= tb.bottom - 5 && b.centerY() < tb.bottom + 0.16 * h && b.centerY() < 0.45 * h
        }.minByOrNull { it.boundingBox!!.top }
        val spell = nameLine?.let { build.matchSpell(it.text) }
        if (spell == null || spell.special == null) {
            Toast.makeText(this, "Sort de l'éveil non reconnu", Toast.LENGTH_SHORT).show(); return
        }
        val target = norm(spell.special)
        val centers = doubleArrayOf(0.282, 0.515, 0.749)
        val lower = lines.filter { it.boundingBox!!.centerY() > 0.55 * h }
        for (cf in centers) {
            val cx = (cf * w).toInt()
            val name = lower.filter { abs(it.boundingBox!!.centerX() - cx) < 0.12 * w }
                .minByOrNull { it.boundingBox!!.top } ?: continue
            val n = norm(name.text)
            val score = 1.0 - levenshtein(n, target).toDouble() / maxOf(n.length, target.length)
            if (score >= 0.75) addChip("✅ Éveil du build", Color.rgb(30, 130, 60), cx, (0.475 * h).toInt())
            else addChip("❌ Autre éveil", Color.rgb(180, 40, 40), cx, (0.475 * h).toInt())
        }
        addWatcher()
        main.postDelayed({ clearChips() }, 12000)
    }

    private fun addChip(label: String, color: Int, cx: Int, cy: Int) {
        val v = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 15f
            setPadding(28, 12, 28, 12); gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = 40f; setColor(color); alpha = 235 }
        }
        v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val lp = overlayParams(cx - v.measuredWidth / 2, cy - v.measuredHeight / 2)
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm.addView(v, lp)
        chips.add(v)
    }

    // fenêtre de 1 px qui détecte un toucher ailleurs (ex. choix d'une carte) et efface les pastilles
    private fun addWatcher() {
        val v = View(this)
        v.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_OUTSIDE) main.postDelayed({ clearChips() }, 350)
            false
        }
        val lp = overlayParams(0, 0)
        lp.width = 1; lp.height = 1
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
        wm.addView(v, lp)
        chips.add(v)
    }

    override fun onDestroy() {
        clearChips()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        synchronized(lock) { lastImage?.close(); lastImage = null }
        display?.release(); reader?.close()
        projection?.stop()
        recognizer.close()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
