package com.buildoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

class OverlayService : Service() {
    companion object {
        const val ACTION_STOP = "stop"
        private const val CHANNEL = "overlay"
    }

    private lateinit var wm: WindowManager
    private lateinit var items: List<BuildItem>
    private val main = Handler(Looper.getMainLooper())
    private val bgThread = HandlerThread("capture").also { it.start() }
    private val bg = Handler(bgThread.looper)
    private val lock = Any()

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var lastImage: Image? = null
    private var capW = 0
    private var capH = 0

    private var bubble: TextView? = null
    private val chips = mutableListOf<View>()
    private var scanning = false
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (projection != null) return START_NOT_STICKY
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        items = BuildData.load(this)
        startFg()
        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("data", Intent::class.java) else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopSelf() } }
            }, main)
        }
        ensureCapture()
        addBubble()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Build Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Build Overlay actif")
            .setContentText("Touchez la bulle 🎯 dans le jeu pour scanner")
            .addAction(Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_delete), "Arrêter", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    private fun realSize(): IntArray {
        val m = DisplayMetrics()
        val d = getSystemService(DisplayManager::class.java).getDisplay(0)
        @Suppress("DEPRECATION") d.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun ensureCapture() {
        val (w, h, dpi) = realSize().let { Triple(it[0], it[1], it[2]) }
        if (display != null && w == capW && h == capH) return
        synchronized(lock) { lastImage?.close(); lastImage = null }
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        r.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) synchronized(lock) { lastImage?.close(); lastImage = img }
        }, bg)
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "cap", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
        } else {
            display!!.resize(w, h, dpi)
            display!!.surface = r.surface
        }
        reader?.close()
        reader = r
        capW = w; capH = h
    }

    private fun overlayParams(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x; this.y = y
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun addBubble() {
        val lp = overlayParams(20, 300)
        val v = TextView(this).apply {
            text = "🎯"; textSize = 22f; gravity = Gravity.CENTER
            width = 130; height = 130
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.argb(150, 20, 20, 20)) }
        }
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - dx) > 12 || abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(v, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) scan()
            }
            true
        }
        wm.addView(v, lp)
        bubble = v
    }

    private fun clearChips() {
        chips.forEach { try { wm.removeView(it) } catch (_: Exception) {} }
        chips.clear()
    }

    private fun scan() {
        if (scanning) return
        scanning = true
        clearChips()
        bubble?.visibility = View.INVISIBLE
        ensureCapture()
        main.postDelayed({ capture() }, 450)
    }

    private fun toBitmap(img: Image): Bitmap {
        val p = img.planes[0]
        val bw = p.rowStride / p.pixelStride
        val full = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
        p.buffer.rewind()
        full.copyPixelsFromBuffer(p.buffer)
        return if (bw == img.width) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
    }

    private fun capture() {
        val bmp = synchronized(lock) { lastImage?.let { toBitmap(it) } }
        bubble?.visibility = View.VISIBLE
        if (bmp == null) {
            Toast.makeText(this, "Capture impossible (écran protégé ?)", Toast.LENGTH_SHORT).show()
            scanning = false; return
        }
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { showResults(it, bmp.width, bmp.height); scanning = false }
            .addOnFailureListener {
                Toast.makeText(this, "Erreur OCR", Toast.LENGTH_SHORT).show(); scanning = false
            }
    }

    private fun showResults(res: Text, w: Int, h: Int) {
        val lines = res.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
        val headers = lines.filter {
            val n = norm(it.text)
            n.length <= 12 && (n.contains("debloquer") || n.contains("ameliorer"))
        }
        if (headers.isEmpty()) {
            Toast.makeText(this, "Écran de montée de niveau non détecté", Toast.LENGTH_SHORT).show(); return
        }
        for (hd in headers) {
            val hb = hd.boundingBox!!
            val cand = lines.filter { l ->
                val b = l.boundingBox!!
                l !== hd && b.centerY() > hb.bottom - 2 && b.centerY() < hb.bottom + 0.14 * h &&
                    abs(b.centerX() - hb.centerX()) < 0.14 * w
            }.sortedBy { it.boundingBox!!.top }
            var title = ""
            if (cand.isNotEmpty()) {
                title = cand[0].text
                var prev = cand[0].boundingBox!!
                for (l in cand.drop(1)) {
                    val b = l.boundingBox!!
                    if (b.top - prev.bottom < 0.5 * prev.height()) { title += " " + l.text; prev = b } else break
                }
            }
            val item = BuildData.bestMatch(items, title)
            val label: String; val color: Int; var good = false
            if (title.isEmpty()) { label = "❓ Non lu"; color = Color.GRAY }
            else if (item == null) { label = "❌ Hors build"; color = Color.rgb(180, 40, 40) }
            else {
                val c = BuildData.count(this, item)
                if (c >= item.target) { label = "⚠️ Max ${c}/${item.target}"; color = Color.rgb(200, 120, 0) }
                else { label = "✅ Prendre ${c}/${item.target}"; color = Color.rgb(30, 130, 60); good = true }
            }
            addChip(label, color, hb.centerX(), hb.centerY(), item, good)
        }
        main.postDelayed({ clearChips() }, 10000)
    }

    private fun addChip(label: String, color: Int, cx: Int, cy: Int, item: BuildItem?, good: Boolean) {
        val v = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); textSize = 15f
            setPadding(28, 12, 28, 12); gravity = Gravity.CENTER
            background = GradientDrawable().apply { cornerRadius = 40f; setColor(color); alpha = 235 }
            setOnClickListener {
                if (good && item != null) BuildData.increment(this@OverlayService, item)
                clearChips()
            }
        }
        v.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        wm.addView(v, overlayParams(cx - v.measuredWidth / 2, cy - v.measuredHeight / 2))
        chips.add(v)
    }

    override fun onDestroy() {
        clearChips()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        synchronized(lock) { lastImage?.close(); lastImage = null }
        display?.release(); reader?.close()
        projection?.stop()
        recognizer.close()
        bgThread.quitSafely()
        super.onDestroy()
    }
}
